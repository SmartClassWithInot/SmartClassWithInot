console.log("SmartClass Galaxy Ready 🚀");

const btn = document.querySelector(".btn");

btn.addEventListener("click", () => {
alert("🚀 Selamat Belajar Deby!");
});
